///////////////////////////////////////Fonctionement du programme Lion/Gazelle/////////////////////////////////////////////////////////////////


	*Au lancement du programme vous pouvez : -Choisir le nombre d'animal qui peuple le monde 
						 -Choisir la taille de la scene en x et en y 
						 -Coisir l'Energie initiale des animaux 
						 -Choisir la Vitesse de chaque animaux 


	*Lorsque le programme est lancé : -Vous pouvez modifier la vitesse des animaux.
				
	
	*Important pour l'utilisation du Refresh : 
		     - Refresh possible uniquement avec le même nombre d'animal(Ne pas modifier le nbAnimal lorsque le programme est lancé)

		     -Pour repeupler le monde une fois que tout les animaux sont morts vous pouvez : 
				-Faire un Refresh, puis un Start.
				-Quittez le Programme, et relancer avec Start.

		     -Des problèmes peuvent survenir lors de l'utilisation du Refresh, car je n'ai pas trouvé le moyen de vider complètement 			      mes vecteurs.(Problème avec les images d'animal mort qui ne s'éffacent pas même avec le refresh qui n'est pas terminé)

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

	
