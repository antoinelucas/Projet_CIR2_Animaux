#include "Gazelle.h"

//Getter permettant de retourner la lettre correspondant à l'Animal, G pour la gazelle.
char Gazelle::getLettre(){
		return lettre;
}